/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _DevicesManagementManager_H_
#define _DevicesManagementManager_H_

#include <string>
#include <cstring>
#include <list>
#include <glib.h>
#include "TaskEnvelope.h"
#include "TaskRequest.h"
#include "MetadataEnvelope.h"
#include "TaskByDidListEnvelope.h"
#include "DeviceTypesInfoEnvelope.h"
#include "MetadataPropertiesEnvelope.h"
#include "TaskStatusesEnvelope.h"
#include "TaskStatusesHistoryEnvelope.h"
#include "TaskListEnvelope.h"
#include "MetadataQueryEnvelope.h"
#include "DeviceTypesInfo.h"
#include "TaskUpdateRequest.h"
#include "TaskUpdateResponse.h"
#include "DeviceTaskUpdateRequest.h"
#include "DeviceTaskUpdateResponse.h"
#include "Error.h"

/** \defgroup Operations API Endpoints
 *  Classes containing all the functions for calling API endpoints
 *
 */

namespace Tizen{
namespace ArtikCloud {
/** \addtogroup DevicesManagement DevicesManagement
 * \ingroup Operations
 *  @{
 */
class DevicesManagementManager {
public:
	DevicesManagementManager();
	virtual ~DevicesManagementManager();

/*! \brief Create a new task for one or more devices. *Synchronous*
 *
 * Create a new task for one or more devices
 * \param taskPayload Task object to be created *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool createTasksSync(char * accessToken,
	TaskRequest taskPayload, 
	void(* handler)(TaskEnvelope, Error, void* )
	, void* userData);

/*! \brief Create a new task for one or more devices. *Asynchronous*
 *
 * Create a new task for one or more devices
 * \param taskPayload Task object to be created *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool createTasksAsync(char * accessToken,
	TaskRequest taskPayload, 
	void(* handler)(TaskEnvelope, Error, void* )
	, void* userData);


/*! \brief Deletes a device's properties.. *Synchronous*
 *
 * Deletes a device's properties.
 * \param did Device ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool deleteServerPropertiesSync(char * accessToken,
	std::string did, 
	void(* handler)(MetadataEnvelope, Error, void* )
	, void* userData);

/*! \brief Deletes a device's properties.. *Asynchronous*
 *
 * Deletes a device's properties.
 * \param did Device ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool deleteServerPropertiesAsync(char * accessToken,
	std::string did, 
	void(* handler)(MetadataEnvelope, Error, void* )
	, void* userData);


/*! \brief Returns the list of tasks for a particular device id with optional status filter.. *Synchronous*
 *
 * Returns the list of tasks for a particular device id with optional status filter.
 * \param did Device ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param status Status filter. Comma-separated statuses.
 * \param order Sort results by a field. Valid fields: createdOn.
 * \param sort Sort order. Valid values: asc or desc.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getAllByDidSync(char * accessToken,
	std::string did, int count, int offset, std::string status, std::string order, std::string sort, 
	void(* handler)(TaskByDidListEnvelope, Error, void* )
	, void* userData);

/*! \brief Returns the list of tasks for a particular device id with optional status filter.. *Asynchronous*
 *
 * Returns the list of tasks for a particular device id with optional status filter.
 * \param did Device ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param status Status filter. Comma-separated statuses.
 * \param order Sort results by a field. Valid fields: createdOn.
 * \param sort Sort order. Valid values: asc or desc.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getAllByDidAsync(char * accessToken,
	std::string did, int count, int offset, std::string status, std::string order, std::string sort, 
	void(* handler)(TaskByDidListEnvelope, Error, void* )
	, void* userData);


/*! \brief Read a device type device management information.. *Synchronous*
 *
 * Read a device type device management information.
 * \param dtid Device type ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getDeviceTypesInfoSync(char * accessToken,
	std::string dtid, 
	void(* handler)(DeviceTypesInfoEnvelope, Error, void* )
	, void* userData);

/*! \brief Read a device type device management information.. *Asynchronous*
 *
 * Read a device type device management information.
 * \param dtid Device type ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getDeviceTypesInfoAsync(char * accessToken,
	std::string dtid, 
	void(* handler)(DeviceTypesInfoEnvelope, Error, void* )
	, void* userData);


/*! \brief Get a device type's device management manifest properties. *Synchronous*
 *
 * Get a device type's device management manifest properties
 * \param dtid Device Type ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getManifestPropertiesSync(char * accessToken,
	std::string dtid, 
	void(* handler)(MetadataPropertiesEnvelope, Error, void* )
	, void* userData);

/*! \brief Get a device type's device management manifest properties. *Asynchronous*
 *
 * Get a device type's device management manifest properties
 * \param dtid Device Type ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getManifestPropertiesAsync(char * accessToken,
	std::string dtid, 
	void(* handler)(MetadataPropertiesEnvelope, Error, void* )
	, void* userData);


/*! \brief Read a device's properties.. *Synchronous*
 *
 * Read a device's properties.
 * \param did Device ID. *Required*
 * \param includeTimestamp Include timestamp.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getPropertiesSync(char * accessToken,
	std::string did, bool includeTimestamp, 
	void(* handler)(MetadataEnvelope, Error, void* )
	, void* userData);

/*! \brief Read a device's properties.. *Asynchronous*
 *
 * Read a device's properties.
 * \param did Device ID. *Required*
 * \param includeTimestamp Include timestamp.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getPropertiesAsync(char * accessToken,
	std::string did, bool includeTimestamp, 
	void(* handler)(MetadataEnvelope, Error, void* )
	, void* userData);


/*! \brief Returns the details and status of a task id and the individual statuses of each device id in the list.. *Synchronous*
 *
 * Returns the details and status of a task id and the individual statuses of each device id in the list.
 * \param tid Task ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param status Status filter. Comma-separated statuses.
 * \param dids Devices filter. Comma-separated device IDs.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getStatusesSync(char * accessToken,
	std::string tid, int count, int offset, std::string status, std::string dids, 
	void(* handler)(TaskStatusesEnvelope, Error, void* )
	, void* userData);

/*! \brief Returns the details and status of a task id and the individual statuses of each device id in the list.. *Asynchronous*
 *
 * Returns the details and status of a task id and the individual statuses of each device id in the list.
 * \param tid Task ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param status Status filter. Comma-separated statuses.
 * \param dids Devices filter. Comma-separated device IDs.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getStatusesAsync(char * accessToken,
	std::string tid, int count, int offset, std::string status, std::string dids, 
	void(* handler)(TaskStatusesEnvelope, Error, void* )
	, void* userData);


/*! \brief Returns the history of the status changes for a specific task id, or for a specific device id in that task.. *Synchronous*
 *
 * Returns the history of the status changes for a specific task id, or for a specific device id in that task.
 * \param tid Task ID. *Required*
 * \param did Device ID. Optional.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getStatusesHistorySync(char * accessToken,
	std::string tid, std::string did, 
	void(* handler)(TaskStatusesHistoryEnvelope, Error, void* )
	, void* userData);

/*! \brief Returns the history of the status changes for a specific task id, or for a specific device id in that task.. *Asynchronous*
 *
 * Returns the history of the status changes for a specific task id, or for a specific device id in that task.
 * \param tid Task ID. *Required*
 * \param did Device ID. Optional.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getStatusesHistoryAsync(char * accessToken,
	std::string tid, std::string did, 
	void(* handler)(TaskStatusesHistoryEnvelope, Error, void* )
	, void* userData);


/*! \brief Returns the details and global status of a specific task id.. *Synchronous*
 *
 * Returns the details and global status of a specific task id.
 * \param tid Task ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getTaskByIDSync(char * accessToken,
	std::string tid, 
	void(* handler)(TaskEnvelope, Error, void* )
	, void* userData);

/*! \brief Returns the details and global status of a specific task id.. *Asynchronous*
 *
 * Returns the details and global status of a specific task id.
 * \param tid Task ID. *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getTaskByIDAsync(char * accessToken,
	std::string tid, 
	void(* handler)(TaskEnvelope, Error, void* )
	, void* userData);


/*! \brief Returns the all the tasks for a device type.. *Synchronous*
 *
 * Returns the all the tasks for a device type.
 * \param dtid Device Type ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param status Status filter. Comma-separated statuses.
 * \param order Sort results by a field. Valid fields: createdOn.
 * \param sort Sort order. Valid values: asc or desc.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getTasksSync(char * accessToken,
	std::string dtid, int count, int offset, std::string status, std::string order, std::string sort, 
	void(* handler)(TaskListEnvelope, Error, void* )
	, void* userData);

/*! \brief Returns the all the tasks for a device type.. *Asynchronous*
 *
 * Returns the all the tasks for a device type.
 * \param dtid Device Type ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param status Status filter. Comma-separated statuses.
 * \param order Sort results by a field. Valid fields: createdOn.
 * \param sort Sort order. Valid values: asc or desc.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool getTasksAsync(char * accessToken,
	std::string dtid, int count, int offset, std::string status, std::string order, std::string sort, 
	void(* handler)(TaskListEnvelope, Error, void* )
	, void* userData);


/*! \brief Query device properties across devices.. *Synchronous*
 *
 * Query device properties across devices.
 * \param dtid Device Type ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param filter Query filter. Comma-separated key=value pairs
 * \param includeTimestamp Include timestamp.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool queryPropertiesSync(char * accessToken,
	std::string dtid, int count, int offset, std::string filter, bool includeTimestamp, 
	void(* handler)(MetadataQueryEnvelope, Error, void* )
	, void* userData);

/*! \brief Query device properties across devices.. *Asynchronous*
 *
 * Query device properties across devices.
 * \param dtid Device Type ID. *Required*
 * \param count Max results count.
 * \param offset Result starting offset.
 * \param filter Query filter. Comma-separated key=value pairs
 * \param includeTimestamp Include timestamp.
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool queryPropertiesAsync(char * accessToken,
	std::string dtid, int count, int offset, std::string filter, bool includeTimestamp, 
	void(* handler)(MetadataQueryEnvelope, Error, void* )
	, void* userData);


/*! \brief Updates a device type information. *Synchronous*
 *
 * Updates a device type information
 * \param dtid Device type ID. *Required*
 * \param deviceTypeInfo Device type info object to be set *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateDeviceTypesInfoSync(char * accessToken,
	std::string dtid, DeviceTypesInfo deviceTypeInfo, 
	void(* handler)(DeviceTypesInfoEnvelope, Error, void* )
	, void* userData);

/*! \brief Updates a device type information. *Asynchronous*
 *
 * Updates a device type information
 * \param dtid Device type ID. *Required*
 * \param deviceTypeInfo Device type info object to be set *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateDeviceTypesInfoAsync(char * accessToken,
	std::string dtid, DeviceTypesInfo deviceTypeInfo, 
	void(* handler)(DeviceTypesInfoEnvelope, Error, void* )
	, void* userData);


/*! \brief Updates a device's server properties.. *Synchronous*
 *
 * Updates a device's server properties.
 * \param did Device ID. *Required*
 * \param deviceProperties Device properties object to be set *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateServerPropertiesSync(char * accessToken,
	std::string did, std::string deviceProperties, 
	void(* handler)(MetadataEnvelope, Error, void* )
	, void* userData);

/*! \brief Updates a device's server properties.. *Asynchronous*
 *
 * Updates a device's server properties.
 * \param did Device ID. *Required*
 * \param deviceProperties Device properties object to be set *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateServerPropertiesAsync(char * accessToken,
	std::string did, std::string deviceProperties, 
	void(* handler)(MetadataEnvelope, Error, void* )
	, void* userData);


/*! \brief Updates a task for all devices - For now just allows changing the state to cancelled.. *Synchronous*
 *
 * Updates a task for all devices - For now just allows changing the state to cancelled.
 * \param tid Task ID. *Required*
 * \param taskUpdateRequest Task update request *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateTaskSync(char * accessToken,
	std::string tid, TaskUpdateRequest taskUpdateRequest, 
	void(* handler)(TaskUpdateResponse, Error, void* )
	, void* userData);

/*! \brief Updates a task for all devices - For now just allows changing the state to cancelled.. *Asynchronous*
 *
 * Updates a task for all devices - For now just allows changing the state to cancelled.
 * \param tid Task ID. *Required*
 * \param taskUpdateRequest Task update request *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateTaskAsync(char * accessToken,
	std::string tid, TaskUpdateRequest taskUpdateRequest, 
	void(* handler)(TaskUpdateResponse, Error, void* )
	, void* userData);


/*! \brief Updates a task for a specific device - For now just allows changing the state to cancelled.. *Synchronous*
 *
 * Updates a task for a specific device - For now just allows changing the state to cancelled.
 * \param tid Task ID. *Required*
 * \param did Device ID. *Required*
 * \param deviceTaskUpdateRequest Device task update request *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateTaskForDeviceSync(char * accessToken,
	std::string tid, std::string did, DeviceTaskUpdateRequest deviceTaskUpdateRequest, 
	void(* handler)(DeviceTaskUpdateResponse, Error, void* )
	, void* userData);

/*! \brief Updates a task for a specific device - For now just allows changing the state to cancelled.. *Asynchronous*
 *
 * Updates a task for a specific device - For now just allows changing the state to cancelled.
 * \param tid Task ID. *Required*
 * \param did Device ID. *Required*
 * \param deviceTaskUpdateRequest Device task update request *Required*
 * \param handler The callback function to be invoked on completion. *Required*
 * \param accessToken The Authorization token. *Required*
 * \param userData The user data to be passed to the callback function.
 */
bool updateTaskForDeviceAsync(char * accessToken,
	std::string tid, std::string did, DeviceTaskUpdateRequest deviceTaskUpdateRequest, 
	void(* handler)(DeviceTaskUpdateResponse, Error, void* )
	, void* userData);



	static std::string getBasePath()
	{
		return "https://api.artik.cloud/v1.1";
	}
};
/** @}*/

}
}
#endif /* DevicesManagementManager_H_ */
