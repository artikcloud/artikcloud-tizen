/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * Task.h
 *
 * 
 */

#ifndef _Task_H_
#define _Task_H_


#include <string>
#include "TaskParameters.h"
#include "TaskStatusCounts.h"
#include <list>
#include "Object.h"

/** \defgroup Models Data Structures for API
 *  Classes containing all the Data Structures needed for calling/returned by API endpoints
 *
 */

namespace Tizen {
namespace ArtikCloud {


/*! \brief 
 *
 *  \ingroup Models
 *
 */

class Task : public Object {
public:
	/*! \brief Constructor.
	 */
	Task();
	Task(char* str);

	/*! \brief Destructor.
	 */
	virtual ~Task();

	/*! \brief Retrieve a string JSON representation of this class.
	 */
	char* toJson();

	/*! \brief Fills in members of this class from JSON string representing it.
	 */
	void fromJson(char* jsonStr);

	/*! \brief Get Filter
	 */
	std::string getFilter();

	/*! \brief Set Filter
	 */
	void setFilter(std::string  filter);
	/*! \brief Get Task type
	 */
	std::string getTaskType();

	/*! \brief Set Task type
	 */
	void setTaskType(std::string  taskType);
	/*! \brief Get Modified on
	 */
	long long getModifiedOn();

	/*! \brief Set Modified on
	 */
	void setModifiedOn(long long  modifiedOn);
	/*! \brief Get Device Type ID
	 */
	std::string getDtid();

	/*! \brief Set Device Type ID
	 */
	void setDtid(std::string  dtid);
	/*! \brief Get Status counts
	 */
	TaskStatusCounts getStatusCounts();

	/*! \brief Set Status counts
	 */
	void setStatusCounts(TaskStatusCounts  statusCounts);
	/*! \brief Get Property
	 */
	std::string getProperty();

	/*! \brief Set Property
	 */
	void setProperty(std::string  property);
	/*! \brief Get Task ID
	 */
	std::string getId();

	/*! \brief Set Task ID
	 */
	void setId(std::string  id);
	/*! \brief Get Device IDs
	 */
	std::list<std::string> getDids();

	/*! \brief Set Device IDs
	 */
	void setDids(std::list <std::string> dids);
	/*! \brief Get Task parameters
	 */
	TaskParameters getTaskParameters();

	/*! \brief Set Task parameters
	 */
	void setTaskParameters(TaskParameters  taskParameters);
	/*! \brief Get Created on
	 */
	long long getCreatedOn();

	/*! \brief Set Created on
	 */
	void setCreatedOn(long long  createdOn);
	/*! \brief Get Status
	 */
	std::string getStatus();

	/*! \brief Set Status
	 */
	void setStatus(std::string  status);

private:
	std::string filter;
	std::string taskType;
	long long modifiedOn;
	std::string dtid;
	TaskStatusCounts statusCounts;
	std::string property;
	std::string id;
	std::list <std::string>dids;
	TaskParameters taskParameters;
	long long createdOn;
	std::string status;
	void __init();
	void __cleanup();
};
}
}

#endif /* _Task_H_ */
