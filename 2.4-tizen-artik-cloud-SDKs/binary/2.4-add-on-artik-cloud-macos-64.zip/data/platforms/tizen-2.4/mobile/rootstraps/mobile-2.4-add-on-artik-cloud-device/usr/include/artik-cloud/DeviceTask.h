/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * DeviceTask.h
 *
 * 
 */

#ifndef _DeviceTask_H_
#define _DeviceTask_H_


#include <string>
#include "Object.h"

/** \defgroup Models Data Structures for API
 *  Classes containing all the Data Structures needed for calling/returned by API endpoints
 *
 */

namespace Tizen {
namespace ArtikCloud {


/*! \brief 
 *
 *  \ingroup Models
 *
 */

class DeviceTask : public Object {
public:
	/*! \brief Constructor.
	 */
	DeviceTask();
	DeviceTask(char* str);

	/*! \brief Destructor.
	 */
	virtual ~DeviceTask();

	/*! \brief Retrieve a string JSON representation of this class.
	 */
	char* toJson();

	/*! \brief Fills in members of this class from JSON string representing it.
	 */
	void fromJson(char* jsonStr);

	/*! \brief Get Number of attempts
	 */
	int getNumAttempts();

	/*! \brief Set Number of attempts
	 */
	void setNumAttempts(int  numAttempts);
	/*! \brief Get Error Message
	 */
	std::string getErrorMessage();

	/*! \brief Set Error Message
	 */
	void setErrorMessage(std::string  errorMessage);
	/*! \brief Get Error Code
	 */
	std::string getErrorCode();

	/*! \brief Set Error Code
	 */
	void setErrorCode(std::string  errorCode);
	/*! \brief Get Device ID
	 */
	std::string getDid();

	/*! \brief Set Device ID
	 */
	void setDid(std::string  did);
	/*! \brief Get Status
	 */
	std::string getStatus();

	/*! \brief Set Status
	 */
	void setStatus(std::string  status);
	/*! \brief Get Timestamp of most recent status change
	 */
	long long getTs();

	/*! \brief Set Timestamp of most recent status change
	 */
	void setTs(long long  ts);

private:
	int numAttempts;
	std::string errorMessage;
	std::string errorCode;
	std::string did;
	std::string status;
	long long ts;
	void __init();
	void __cleanup();
};
}
}

#endif /* _DeviceTask_H_ */
