/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * TaskByDidListEnvelope.h
 *
 * 
 */

#ifndef _TaskByDidListEnvelope_H_
#define _TaskByDidListEnvelope_H_


#include <string>
#include "TaskByDidList.h"
#include "Object.h"

/** \defgroup Models Data Structures for API
 *  Classes containing all the Data Structures needed for calling/returned by API endpoints
 *
 */

namespace Tizen {
namespace ArtikCloud {


/*! \brief 
 *
 *  \ingroup Models
 *
 */

class TaskByDidListEnvelope : public Object {
public:
	/*! \brief Constructor.
	 */
	TaskByDidListEnvelope();
	TaskByDidListEnvelope(char* str);

	/*! \brief Destructor.
	 */
	virtual ~TaskByDidListEnvelope();

	/*! \brief Retrieve a string JSON representation of this class.
	 */
	char* toJson();

	/*! \brief Fills in members of this class from JSON string representing it.
	 */
	void fromJson(char* jsonStr);

	/*! \brief Get Total number of tasks in list
	 */
	int getTotal();

	/*! \brief Set Total number of tasks in list
	 */
	void setTotal(int  total);
	/*! \brief Get Device task list envelope
	 */
	TaskByDidList getData();

	/*! \brief Set Device task list envelope
	 */
	void setData(TaskByDidList  data);
	/*! \brief Get Offset if using pagination
	 */
	int getOffset();

	/*! \brief Set Offset if using pagination
	 */
	void setOffset(int  offset);
	/*! \brief Get Count for current result set
	 */
	int getCount();

	/*! \brief Set Count for current result set
	 */
	void setCount(int  count);

private:
	int total;
	TaskByDidList data;
	int offset;
	int count;
	void __init();
	void __cleanup();
};
}
}

#endif /* _TaskByDidListEnvelope_H_ */
