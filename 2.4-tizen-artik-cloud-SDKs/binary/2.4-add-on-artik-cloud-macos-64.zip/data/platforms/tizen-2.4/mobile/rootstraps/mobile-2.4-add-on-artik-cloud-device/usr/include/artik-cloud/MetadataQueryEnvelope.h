/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd All Rights Reserved
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * MetadataQueryEnvelope.h
 *
 * 
 */

#ifndef _MetadataQueryEnvelope_H_
#define _MetadataQueryEnvelope_H_


#include <string>
#include <list>
#include <map>
#include "Object.h"

/** \defgroup Models Data Structures for API
 *  Classes containing all the Data Structures needed for calling/returned by API endpoints
 *
 */

namespace Tizen {
namespace ArtikCloud {


/*! \brief 
 *
 *  \ingroup Models
 *
 */

class MetadataQueryEnvelope : public Object {
public:
	/*! \brief Constructor.
	 */
	MetadataQueryEnvelope();
	MetadataQueryEnvelope(char* str);

	/*! \brief Destructor.
	 */
	virtual ~MetadataQueryEnvelope();

	/*! \brief Retrieve a string JSON representation of this class.
	 */
	char* toJson();

	/*! \brief Fills in members of this class from JSON string representing it.
	 */
	void fromJson(char* jsonStr);

	/*! \brief Get Number of results found
	 */
	int getTotal();

	/*! \brief Set Number of results found
	 */
	void setTotal(int  total);
	/*! \brief Get Array of objects with device's metadata
	 */
	std::map<std::string, std::string> getData();

	/*! \brief Set Array of objects with device's metadata
	 */
	void setData(std::map <std::string, std::string> data);
	/*! \brief Get Page starting position
	 */
	int getOffset();

	/*! \brief Set Page starting position
	 */
	void setOffset(int  offset);
	/*! \brief Get Page size
	 */
	int getCount();

	/*! \brief Set Page size
	 */
	void setCount(int  count);

private:
	int total;
	std::map <std::string, std::string>data;
	int offset;
	int count;
	void __init();
	void __cleanup();
};
}
}

#endif /* _MetadataQueryEnvelope_H_ */
